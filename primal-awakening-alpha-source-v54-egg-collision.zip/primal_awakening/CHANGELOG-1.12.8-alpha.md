# Primal Awakening 1.12.8-alpha

- Adjusted desert dragon growth timing by stage: 7, 10, 15, and 20 Minecraft days.
- Growth progress remains saved with the entity.
- Total time from stage 1 to stage 5: 52 Minecraft days (about 17 hours 20 minutes of continuous in-game ticking).
- This source archive has not been compiled or tested in Minecraft.
