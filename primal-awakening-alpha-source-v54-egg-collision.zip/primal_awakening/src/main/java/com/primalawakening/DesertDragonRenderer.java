package com.primalawakening;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class DesertDragonRenderer extends MobRenderer<DesertDragonEntity, DesertDragonModel> {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[] {
        new ResourceLocation(PrimalAwakening.MOD_ID,"textures/entity/desert_dragon_sand.png"),
        new ResourceLocation(PrimalAwakening.MOD_ID,"textures/entity/desert_dragon_bronze.png"),
        new ResourceLocation(PrimalAwakening.MOD_ID,"textures/entity/desert_dragon_ivory.png"),
        new ResourceLocation(PrimalAwakening.MOD_ID,"textures/entity/desert_dragon_terracotta.png")
    };
    public DesertDragonRenderer(EntityRendererProvider.Context context) { super(context,new DesertDragonModel(context.bakeLayer(DesertDragonClient.LAYER)),1.2F); }
    @Override public ResourceLocation getTextureLocation(DesertDragonEntity entity) { return TEXTURES[entity.getVariant()]; }
    @Override protected void scale(DesertDragonEntity entity, PoseStack pose, float partialTick) { float s=0.65F+entity.getAgeStage()*0.18F; pose.scale(s,s,s); }
}
