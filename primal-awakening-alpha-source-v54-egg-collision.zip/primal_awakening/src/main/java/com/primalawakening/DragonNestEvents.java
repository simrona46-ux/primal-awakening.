package com.primalawakening;

import com.github.alexthe666.iceandfire.entity.EntityDragonBase;
import com.github.alexthe666.iceandfire.entity.EntityDragonEgg;
import com.github.alexthe666.iceandfire.entity.util.HomePosition;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashSet;
import java.util.Set;

/** Server-side nest bookkeeping and basic territorial behaviour for wild lair dragons. */
@Mod.EventBusSubscriber(modid = PrimalAwakening.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class DragonNestEvents {
    private static final String PROCESSED_TAG = "primalawakening_nest_processed_v4";
    private static final float BABY_CHANCE = 0.15F;
    private static final double NEST_DEFENSE_RADIUS = 24.0D;
    private static final String NEST_HATCHLING_TAG = "primalawakening_nest_hatchling";
    private static final String NEST_HOME_X_TAG = "primalawakening_nest_home_x";
    private static final String NEST_HOME_Y_TAG = "primalawakening_nest_home_y";
    private static final String NEST_HOME_Z_TAG = "primalawakening_nest_home_z";
    private static final double HATCHLING_DANGER_RADIUS = 14.0D;
    private static final String DATA_NAME = "primalawakening_nests_v3";
    private static final String NEXT_DODGE_TAG = "primalawakening_next_dodge";
    private static final String NEXT_CHARGE_TAG = "primalawakening_next_charge";
    private static final String NEXT_FLANK_TAG = "primalawakening_next_flank";
    private static final long FLANK_COOLDOWN_TICKS = 100L;
    private static final long CHARGE_COOLDOWN_TICKS = 100L;
    private static final double PACK_ASSIST_RADIUS = 24.0D;
    private static final double DODGE_SCAN_RADIUS = 6.0D;
    private static final double DODGE_PATH_RADIUS = 1.65D;
    private static final double DODGE_MAX_PREDICTION_TICKS = 12.0D;
    private static final long DODGE_COOLDOWN_TICKS = 50L;
    private static final String NEXT_ROAR_TAG = "primalawakening_next_roar";
    private static final long ROAR_COOLDOWN_TICKS = 240L;
    private static final double ROAR_RADIUS = 5.5D;
    private static final String NEXT_SLAM_TAG = "primalawakening_next_slam";
    private static final String SLAM_WINDUP_TAG = "primalawakening_slam_windup_until";
    private static final String SLAM_ENRAGED_TAG = "primalawakening_slam_enraged";
    private static final String NEXT_SPECIAL_TAG = "primalawakening_next_special";
    private static final long SLAM_COOLDOWN_TICKS = 160L;
    private static final long SPECIAL_LOCKOUT_TICKS = 60L;
    private static final double SLAM_RADIUS = 3.2D;
    private static final String NEXT_SANDSTORM_TAG = "primalawakening_next_sandstorm";
    private static final long SANDSTORM_COOLDOWN_TICKS = 600L;
    private static final double SANDSTORM_RADIUS = 6.5D;
    private static final String NEXT_HOT_SAND_TAG = "primalawakening_next_hot_sand";
    private static final String DESERT_LAIR_DECORATED_TAG = "primalawakening_desert_lair_decorated_v2";
    private static final long HOT_SAND_COOLDOWN_TICKS = 420L;
    private static final double HOT_SAND_RADIUS = 4.5D;

    private DragonNestEvents() {}

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinWorldEvent event) {
        if (!(event.getWorld() instanceof ServerLevel level)) return;

        // Roll the appearance once for each newly spawned custom desert dragon.
        // Persistent data prevents re-randomizing its color when chunks are reloaded.
        if (event.getEntity() instanceof DesertDragonEntity desertDragon) {
            CompoundTag data = desertDragon.getPersistentData();
            if (!data.getBoolean("primalawakening_variant_initialized")) {
                int roll = level.random.nextInt(100);
                // Sand is common; the three unusual colors are progressively rarer.
                int variant = roll < 50 ? 0 : roll < 75 ? 1 : roll < 90 ? 2 : 3;
                desertDragon.setVariant(variant);
                data.putBoolean("primalawakening_variant_initialized", true);
            }
            return;
        }

        if (!(event.getEntity() instanceof EntityDragonBase dragon)) return;
        tryProcessNest(dragon, level);
    }

    /**
     * Registers a lair only when its home chunk is already loaded. If the dragon
     * joins while far from an unloaded home chunk, the periodic tick hook retries
     * later instead of silently consuming the egg/baby roll.
     */
    private static void tryProcessNest(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.isRemoved() || dragon.isMobDead() || dragon.homePos == null || dragon.isTame()) return;
        if (dragon.getPersistentData().getBoolean(PROCESSED_TAG)) return;
        if (!isInHomeDimension(dragon, level)) return;

        BlockPos home = dragon.homePos.getPosition();
        if (home == null || !level.hasChunkAt(home)) return;

        NestData nests = NestData.get(level);
        String key = nestKey(level, home);

        // A lair is processed only once. This prevents a second adult dragon sharing
        // the same home position from creating another egg or hatchling after reload.
        if (nests.processedNests.contains(key)) {
            dragon.getPersistentData().putBoolean(PROCESSED_TAG, true);
            return;
        }

        // Eggs and hatchlings may only be created by a female. Mark a male as checked
        // without reserving the lair's offspring slot.
        if (dragon.isMale()) {
            dragon.getPersistentData().putBoolean(PROCESSED_TAG, true);
            return;
        }

        // Migrate safely if an egg from this mod is already present near the lair.
        if (hasOurEggNear(level, home, dragon)) {
            nests.processedNests.add(key);
            nests.setDirty();
            dragon.getPersistentData().putBoolean(PROCESSED_TAG, true);
            return;
        }

        // HomePosition may be the structure origin rather than the visible nest floor.
        BlockPos eggFloor = findEggSpawnFloor(level, home);
        if (eggFloor == null) return;

        // One female nest gets exactly one outcome: either a hatchling or an egg,
        // never both. BABY_CHANCE is rolled once for the whole nest.
        if (level.random.nextFloat() < BABY_CHANCE) {
            Entity created = dragon.getType().create(level);
            if (created instanceof EntityDragonBase baby) {
                BlockPos babyFloor = findBabySpawnFloor(level, eggFloor);
                if (babyFloor != null) {
                    baby.moveTo(babyFloor.getX() + 0.5D, babyFloor.getY() + 1.02D,
                            babyFloor.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
                    baby.setVariant(dragon.getVariant());
                    baby.setGender(level.random.nextBoolean());
                    baby.growDragon(1);
                    baby.homePos = new HomePosition(home, level);
                    baby.hasHomePosition = true;
                    baby.getPersistentData().putBoolean(PROCESSED_TAG, true);
                    baby.getPersistentData().putBoolean(NEST_HATCHLING_TAG, true);
                    baby.getPersistentData().putUUID("primalawakening_parent", dragon.getUUID());
                    tagNestHome(baby.getPersistentData(), home);
                    if (level.noCollision(baby) && level.addFreshEntity(baby)) {
                        markNestProcessed(nests, key, dragon);
                        return;
                    }
                }
                // Do not leave the nest empty if the hatchling has no safe spawn space.
                // The fallback egg uses the already validated egg floor.
                baby.discard();
            } else if (created != null) {
                created.discard();
            }
            // If baby creation failed, fall through and create the egg instead.
        }

        // Use Ice and Fire's real dragon-egg entity to retain native rendering,
        // temperature and hatching behavior.
        EntityDragonEgg eggEntity = dragon.createEgg(dragon);
        if (eggEntity == null) return;
        eggEntity.moveTo(eggFloor.getX() + 0.5D, eggFloor.getY() + 1.02D,
                eggFloor.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
        eggEntity.setOwnerId(dragon.getUUID());
        eggEntity.setGlowingTag(true);
        eggEntity.getPersistentData().putBoolean("primalawakening_nest_egg", true);
        tagNestHome(eggEntity.getPersistentData(), home);
        if (!level.addFreshEntity(eggEntity)) return;
        markNestProcessed(nests, key, dragon);
    }

    private static void markNestProcessed(NestData nests, String key, EntityDragonBase dragon) {
        nests.processedNests.add(key);
        nests.setDirty();
        dragon.getPersistentData().putBoolean(PROCESSED_TAG, true);
    }

    /** Finds a nearby safe floor for a hatchling, leaving the egg itself unobstructed. */
    private static BlockPos findBabySpawnFloor(ServerLevel level, BlockPos eggFloor) {
        for (int radius = 1; radius <= 4; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) continue;
                    BlockPos floor = eggFloor.offset(dx, 0, dz);
                    if (!level.hasChunkAt(floor) || !level.hasChunkAt(floor.above(2))) continue;
                    if (!isSafeEggFloor(level, floor)) continue;
                    if (!level.getBlockState(floor.above()).isAir()
                            || !level.getBlockState(floor.above(2)).isAir()) continue;
                    if (!level.getFluidState(floor.above()).isEmpty()
                            || !level.getFluidState(floor.above(2)).isEmpty()) continue;
                    return floor.immutable();
                }
            }
        }
        return null;
    }

    private static boolean hasOurEggNear(ServerLevel level, BlockPos home, EntityDragonBase dragon) {
        // A broad radius alone can confuse two nearby lairs. Prefer exact nest metadata
        // or the egg's owner UUID; legacy entities without metadata use a tight fallback.
        AABB search = new AABB(home).inflate(16.0D, 10.0D, 16.0D);
        for (EntityDragonEgg egg : level.getEntitiesOfClass(EntityDragonEgg.class, search,
                candidate -> candidate.getPersistentData().getBoolean("primalawakening_nest_egg"))) {
            if (belongsToNest(egg.getPersistentData(), home)) return true;
            if (dragon.getUUID().equals(egg.getOwnerId())) return true;
            if (egg.getOwnerId() == null && egg.distanceToSqr(home.getX() + 0.5D,
                    home.getY() + 0.5D, home.getZ() + 0.5D) <= 16.0D) return true;
        }
        // Compatibility for old alpha item-eggs. New entities always store exact nest coordinates.
        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, search,
                candidate -> candidate.getPersistentData().getBoolean("primalawakening_nest_egg"))) {
            if (belongsToNest(item.getPersistentData(), home)) return true;
            if (item.distanceToSqr(home.getX() + 0.5D, home.getY() + 0.5D,
                    home.getZ() + 0.5D) <= 16.0D) return true;
        }
        return false;
    }

    private static void tagNestHome(CompoundTag tag, BlockPos home) {
        tag.putInt(NEST_HOME_X_TAG, home.getX());
        tag.putInt(NEST_HOME_Y_TAG, home.getY());
        tag.putInt(NEST_HOME_Z_TAG, home.getZ());
    }

    private static boolean belongsToNest(CompoundTag tag, BlockPos home) {
        return tag.contains(NEST_HOME_X_TAG) && tag.contains(NEST_HOME_Y_TAG)
                && tag.contains(NEST_HOME_Z_TAG)
                && tag.getInt(NEST_HOME_X_TAG) == home.getX()
                && tag.getInt(NEST_HOME_Y_TAG) == home.getY()
                && tag.getInt(NEST_HOME_Z_TAG) == home.getZ();
    }

    /**
     * Finds a safe egg placement near a lair's home position. Search up to a 17x17
     * horizontal area and eight blocks above/below the saved home Y level because
     * structure home positions are not always located on the visible nest floor.
     */
    private static BlockPos findEggSpawnFloor(ServerLevel level, BlockPos home) {
        int[] yOffsets = {0, 1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6, 7, -7, 8, -8};
        for (int radius = 0; radius <= 8; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) continue;
                    for (int dy : yOffsets) {
                        BlockPos floor = home.offset(dx, dy, dz);
                        if (!level.hasChunkAt(floor) || !level.hasChunkAt(floor.above(2))) continue;
                        if (!isSafeEggFloor(level, floor)) continue;
                        if (!level.getBlockState(floor.above()).isAir()
                                || !level.getBlockState(floor.above(2)).isAir()) continue;
                        if (!level.getFluidState(floor.above()).isEmpty()
                                || !level.getFluidState(floor.above(2)).isEmpty()) continue;
                        return floor.immutable();
                    }
                }
            }
        }
        return null;
    }

    /** Reject unstable or hazardous surfaces so the egg is not placed on fire, fluids, or damaging blocks. */
    private static boolean isSafeEggFloor(ServerLevel level, BlockPos floor) {
        var state = level.getBlockState(floor);
        if (!state.isFaceSturdy(level, floor, Direction.UP)) return false;
        if (!level.getFluidState(floor).isEmpty()) return false;
        return !state.is(Blocks.MAGMA_BLOCK)
                && !state.is(Blocks.CACTUS)
                && !state.is(Blocks.CAMPFIRE)
                && !state.is(Blocks.SOUL_CAMPFIRE)
                && !state.is(Blocks.FIRE)
                && !state.is(Blocks.SOUL_FIRE)
                && !state.is(Blocks.SWEET_BERRY_BUSH)
                && !state.is(Blocks.WITHER_ROSE)
                && !state.is(Blocks.POWDER_SNOW);
    }

    /**
     * A wild adult with a home becomes territorial when a player approaches the lair.
     * The existing Ice and Fire combat AI still chooses and executes the actual attacks.
     */
    @SubscribeEvent
    public static void onDragonTick(LivingEvent.LivingUpdateEvent event) {
        if (!(event.getEntityLiving() instanceof EntityDragonBase dragon)) return;
        if (!(dragon.level instanceof ServerLevel level)) return;
        if (dragon.isRemoved() || dragon.isTame() || dragon.isMobDead()) return;

        // Retry nest processing if the dragon loaded before its home chunk did.
        if (dragon.tickCount % 100 == 0 && dragon.homePos != null
                && !dragon.getPersistentData().getBoolean(PROCESSED_TAG)) {
            tryProcessNest(dragon, level);
        }

        // Prototype treasure-site dressing: attach a small sandstone ruin and an
        // emerald chest to an existing wild adult dragon's desert home. This is
        // intentionally not a standalone world-generation structure yet.
        if (dragon.tickCount % 100 == 0 && dragon.getDragonStage() >= 3
                && dragon.homePos != null
                && !dragon.getPersistentData().getBoolean(DESERT_LAIR_DECORATED_TAG)) {
            tryDecorateDesertLair(dragon, level);
        }

        // Combat layer: wild adult dragons can make a short evasive sidestep against
        // player-fired projectiles. The cooldown is stored in persistent entity data.
        if (dragon.getDragonStage() >= 3 && dragon.tickCount % 5 == 0) {
            tryDodgeProjectile(dragon, level);
            tryCloseDistance(dragon, level);
            tryRoarShockwave(dragon, level);
            tryGroundSlam(dragon, level);
            tryDesertSandstorm(dragon, level);
            tryHotSandBurst(dragon, level);
        }

        // Dragons from the same lair coordinate on an already identified player target.
        // This runs server-side every second and leaves Ice and Fire attack execution intact.
        if (dragon.tickCount % 20 == 0) {
            rallyPack(dragon, level);
            tryPackFlank(dragon, level);
            defendNestHatchlings(dragon, level);
        }

        // Return-to-lair behaviour: after combat ends, mature wild dragons that
        // have wandered well away from their home periodically path back instead
        // of remaining indefinitely at the edge of their pursuit area. Never
        // force-load the home chunk and never interrupt an active target.
        if (dragon.getDragonStage() >= 3 && dragon.tickCount % 100 == 0
                && dragon.homePos != null && dragon.getTarget() == null
                && isInHomeDimension(dragon, level)) {
            BlockPos returnHome = dragon.homePos.getPosition();
            if (returnHome != null && level.hasChunkAt(returnHome)
                    && dragon.distanceToSqr(returnHome.getX() + 0.5D,
                            returnHome.getY() + 0.5D, returnHome.getZ() + 0.5D) > 48.0D * 48.0D) {
                dragon.getNavigation().moveTo(returnHome.getX() + 0.5D,
                        returnHome.getY() + 1.0D, returnHome.getZ() + 0.5D, 1.0D);
            }
        }

        // Territorial logic runs less often to keep the extra AI inexpensive.
        if (dragon.tickCount % 20 != 0 || dragon.homePos == null || dragon.getTarget() != null) return;
        if (dragon.getDragonStage() < 2) return;

        BlockPos home = dragon.homePos.getPosition();
        if (home == null || !isInHomeDimension(dragon, level)) return;
        if (dragon.distanceToSqr(home.getX() + 0.5D, home.getY() + 0.5D, home.getZ() + 0.5D)
                > NEST_DEFENSE_RADIUS * NEST_DEFENSE_RADIUS) return;

        Player intruder = level.getNearestPlayer(dragon, 12.0D);
        if (intruder == null || intruder.isSpectator() || intruder.isCreative()) return;
        if (intruder.distanceToSqr(home.getX() + 0.5D, home.getY() + 0.5D, home.getZ() + 0.5D)
                <= NEST_DEFENSE_RADIUS * NEST_DEFENSE_RADIUS) {
            dragon.setTarget(intruder);
        }
    }

    /**
     * Explicit family defence: wild adult dragons protect hatchlings registered to
     * the same lair. A player approaching a hatchling is treated as a nest threat.
     */
    private static void defendNestHatchlings(EntityDragonBase guardian, ServerLevel level) {
        if (guardian.isTame() || guardian.getDragonStage() < 2 || guardian.homePos == null) return;
        if (!isInHomeDimension(guardian, level)) return;
        BlockPos home = guardian.homePos.getPosition();
        if (home == null) return;

        for (Entity entity : level.getEntities(guardian,
                guardian.getBoundingBox().inflate(NEST_DEFENSE_RADIUS),
                candidate -> candidate instanceof EntityDragonBase
                        && candidate.getPersistentData().getBoolean(NEST_HATCHLING_TAG))) {
            EntityDragonBase hatchling = (EntityDragonBase) entity;
            if (hatchling.isRemoved() || hatchling.isMobDead() || hatchling.homePos == null) continue;
            if (!home.equals(hatchling.homePos.getPosition()) || !isInHomeDimension(hatchling, level)) continue;

            Player intruder = level.getNearestPlayer(hatchling, HATCHLING_DANGER_RADIUS);
            if (intruder == null || intruder.isRemoved() || intruder.isDeadOrDying()
                    || intruder.isSpectator() || intruder.isCreative()) continue;
            if (guardian.getTarget() == null || guardian.getTarget().isDeadOrDying()) {
                guardian.setTarget(intruder);
            }
        }
    }

    /** Nearby wild dragons sharing the same home retaliate when a player injures one of them. */
    /**
     * Age-scaled scale drops for the future dedicated desert-dragon entity.
     * The marker is intentionally required so ordinary Ice and Fire dragons
     * never drop these addon-only materials by accident. The desert entity must
     * set primalawakening_desert_dragon=true and variant=sand|bronze|ivory|terracotta.
     */
    @SubscribeEvent
    public static void onDesertDragonDrops(LivingDropsEvent event) {
        if (!(event.getEntityLiving() instanceof EntityDragonBase dragon)) return;
        if (dragon.level.isClientSide) return;
        CompoundTag data = dragon.getPersistentData();
        if (!data.getBoolean("primalawakening_desert_dragon")) return;

        String variant = data.getString("primalawakening_desert_variant");
        net.minecraft.world.item.Item scaleItem;
        switch (variant) {
            case "bronze" -> scaleItem = DesertScaleItems.BRONZE_SCALE.get();
            case "ivory" -> scaleItem = DesertScaleItems.IVORY_SCALE.get();
            case "terracotta" -> scaleItem = DesertScaleItems.TERRACOTTA_SCALE.get();
            default -> scaleItem = DesertScaleItems.SAND_SCALE.get();
        }

        // Ice and Fire-style progression: older dragons yield substantially more.
        int stage = Math.max(1, Math.min(5, dragon.getDragonStage()));
        int min = switch (stage) { case 1 -> 1; case 2 -> 3; case 3 -> 7; case 4 -> 12; default -> 18; };
        int max = switch (stage) { case 1 -> 3; case 2 -> 7; case 3 -> 12; case 4 -> 18; default -> 24; };
        int count = min + dragon.getRandom().nextInt(max - min + 1);
        while (count > 0) {
            int stackSize = Math.min(count, scaleItem.getMaxStackSize());
            ItemEntity drop = new ItemEntity(dragon.level, dragon.getX(), dragon.getY(), dragon.getZ(),
                    new ItemStack(scaleItem, stackSize));
            event.getDrops().add(drop);
            count -= stackSize;
        }
    }

    @SubscribeEvent
    public static void onDragonHurt(LivingHurtEvent event) {
        if (!(event.getEntityLiving() instanceof EntityDragonBase hurtDragon)) return;
        if (!(hurtDragon.level instanceof ServerLevel level)) return;
        if (!(event.getSource().getEntity() instanceof Player attacker)) return;
        if (attacker.isCreative() || attacker.isSpectator() || hurtDragon.isTame()) return;
        if (hurtDragon.homePos == null) return;

        BlockPos home = hurtDragon.homePos.getPosition();
        if (home == null) return;
        for (Entity entity : level.getEntities(hurtDragon,
                hurtDragon.getBoundingBox().inflate(20.0D),
                candidate -> candidate instanceof EntityDragonBase)) {
            EntityDragonBase ally = (EntityDragonBase) entity;
            if (ally == hurtDragon || ally.isTame() || ally.isRemoved() || ally.homePos == null) continue;
            if (!home.equals(ally.homePos.getPosition())) continue;
            if (ally.getTarget() == null || ally.getTarget().isRemoved()
                    || ally.getTarget().isDeadOrDying()) ally.setTarget(attacker);
        }
        if (hurtDragon.getTarget() == null || hurtDragon.getTarget().isRemoved()
                || hurtDragon.getTarget().isDeadOrDying()) hurtDragon.setTarget(attacker);
    }



    /**
     * Shares a player target with nearby wild dragons from the same home position.
     * Tamed dragons, unrelated lairs, and non-player targets are deliberately excluded.
     */
    private static void rallyPack(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.isTame() || dragon.getDragonStage() < 2 || dragon.homePos == null) return;
        if (!(dragon.getTarget() instanceof Player target)) return;
        if (target.isRemoved() || target.isDeadOrDying() || target.isCreative() || target.isSpectator()) return;

        BlockPos home = dragon.homePos.getPosition();
        if (home == null || !isInHomeDimension(dragon, level)) return;
        if (dragon.distanceToSqr(target) > PACK_ASSIST_RADIUS * PACK_ASSIST_RADIUS) return;

        for (Entity entity : level.getEntities(dragon, dragon.getBoundingBox().inflate(PACK_ASSIST_RADIUS),
                candidate -> candidate instanceof EntityDragonBase)) {
            EntityDragonBase ally = (EntityDragonBase) entity;
            if (ally.isRemoved() || ally.isTame() || ally.isMobDead() || ally.getDragonStage() < 2) continue;
            if (ally.homePos == null || !home.equals(ally.homePos.getPosition())) continue;
            if (!isInHomeDimension(ally, level)) continue;
            Entity currentTarget = ally.getTarget();
            boolean targetIsStale = currentTarget == null || currentTarget.isRemoved()
                    || currentTarget.isDeadOrDying();
            // Refresh a dead/removed target, but never steal an ally from an active fight.
            if (targetIsStale
                    && ally.distanceToSqr(target) <= PACK_ASSIST_RADIUS * PACK_ASSIST_RADIUS) {
                ally.setTarget(target);
            }
        }
    }

    /**
     * Gives an engaged adult a small lateral reposition when a pack ally is also
     * fighting the same player. This is deliberately an impulse, not a teleport: it
     * respects block collision and has a cooldown so vanilla pathfinding can recover.
     */
    private static void tryPackFlank(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.getDragonStage() < 3 || dragon.isTame() || !dragon.isOnGround()
                || dragon.isFlying() || dragon.isBreathingFire() || dragon.homePos == null) return;
        if (!(dragon.getTarget() instanceof Player target)) return;
        if (target.isRemoved() || target.isDeadOrDying() || target.isCreative() || target.isSpectator()) return;

        double distanceSqr = dragon.distanceToSqr(target);
        if (distanceSqr < 36.0D || distanceSqr > 225.0D) return; // 6–15 blocks
        long now = level.getGameTime();
        if (now < dragon.getPersistentData().getLong(NEXT_FLANK_TAG)) return;

        BlockPos home = dragon.homePos.getPosition();
        if (home == null || !isInHomeDimension(dragon, level)) return;
        boolean engagedAlly = false;
        for (Entity entity : level.getEntities(dragon, dragon.getBoundingBox().inflate(PACK_ASSIST_RADIUS),
                candidate -> candidate instanceof EntityDragonBase)) {
            EntityDragonBase ally = (EntityDragonBase) entity;
            if (ally.isRemoved() || ally.isTame() || ally.isMobDead() || ally.getDragonStage() < 2) continue;
            if (ally.homePos == null || !home.equals(ally.homePos.getPosition())) continue;
            if (!isInHomeDimension(ally, level) || ally.getTarget() != target) continue;
            if (ally.distanceToSqr(target) <= PACK_ASSIST_RADIUS * PACK_ASSIST_RADIUS) {
                engagedAlly = true;
                break;
            }
        }
        if (!engagedAlly) return;

        Vec3 awayFromTarget = new Vec3(dragon.getX() - target.getX(), 0.0D,
                dragon.getZ() - target.getZ());
        if (awayFromTarget.lengthSqr() < 1.0E-4D) return;
        awayFromTarget = awayFromTarget.normalize();
        Vec3 side = new Vec3(-awayFromTarget.z, 0.0D, awayFromTarget.x);
        if ((dragon.getId() & 1) != 0) side = side.scale(-1.0D);
        Vec3 opposite = side.scale(-1.0D);
        boolean canSide = level.noCollision(dragon, dragon.getBoundingBox().move(side.x * 1.2D, 0.0D, side.z * 1.2D));
        boolean canOpposite = level.noCollision(dragon, dragon.getBoundingBox().move(opposite.x * 1.2D, 0.0D, opposite.z * 1.2D));
        if (!canSide && !canOpposite) return;
        if (!canSide) side = opposite;

        dragon.setDeltaMovement(dragon.getDeltaMovement().add(side.x * 0.16D, 0.025D, side.z * 0.16D));
        dragon.hasImpulse = true;
        dragon.getPersistentData().putLong(NEXT_FLANK_TAG, now + FLANK_COOLDOWN_TICKS);
        level.sendParticles(ParticleTypes.CLOUD, dragon.getX(), dragon.getY() + 0.15D, dragon.getZ(),
                4, 0.25D, 0.05D, 0.25D, 0.005D);
    }

    /**
     * Prevents dragons from the same lair from stacking their roar, slam, and charge
     * at the same moment. An ally's shared special lockout acts as a short coordination
     * signal; this does not reserve the attack permanently or affect unrelated lairs.
     */
    private static boolean hasNearbyPackSpecialInProgress(EntityDragonBase dragon, ServerLevel level, long now) {
        if (dragon.homePos == null || !isInHomeDimension(dragon, level)) return false;
        BlockPos home = dragon.homePos.getPosition();
        if (home == null) return false;

        for (Entity entity : level.getEntities(dragon,
                dragon.getBoundingBox().inflate(PACK_ASSIST_RADIUS),
                candidate -> candidate instanceof EntityDragonBase)) {
            EntityDragonBase ally = (EntityDragonBase) entity;
            if (ally == dragon || ally.isRemoved() || ally.isTame() || ally.isMobDead()) continue;
            if (ally.getDragonStage() < 2 || ally.homePos == null) continue;
            if (!home.equals(ally.homePos.getPosition()) || !isInHomeDimension(ally, level)) continue;
            if (ally.getPersistentData().getLong(NEXT_SPECIAL_TAG) > now) return true;
        }
        return false;
    }

    /**
     * A short grounded pursuit burst helps adult wild dragons close a gap when a
     * player kites them on foot. It does not replace normal pathfinding, and it is
     * skipped while flying, breathing fire, or when the forward bounding box collides.
     */
    private static void tryCloseDistance(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.getDragonStage() < 3 || !dragon.isOnGround()
                || dragon.isBreathingFire() || dragon.isFlying()) return;
        if (!(dragon.getTarget() instanceof Player target)) return;
        if (target.isRemoved() || target.isDeadOrDying() || target.isCreative() || target.isSpectator()) return;

        double distanceSqr = dragon.distanceToSqr(target);
        if (distanceSqr < 64.0D || distanceSqr > 324.0D) return; // 8–18 blocks

        long now = level.getGameTime();
        boolean enraged = dragon.getMaxHealth() > 0.0F
                && dragon.getHealth() / dragon.getMaxHealth() <= 0.30F;
        long cooldown = enraged ? 70L : CHARGE_COOLDOWN_TICKS;
        if (now < dragon.getPersistentData().getLong(NEXT_CHARGE_TAG)) return;
        if (now < dragon.getPersistentData().getLong(NEXT_SPECIAL_TAG)) return;
        if (hasNearbyPackSpecialInProgress(dragon, level, now)) return;

        // Aim slightly ahead of a sprinting target, but cap the prediction so the
        // burst cannot turn into an abrupt, excessively large movement impulse.
        Vec3 targetMotion = target.getDeltaMovement();
        double lead = target.isSprinting() ? 2.0D : 0.6D;
        Vec3 predicted = target.position().add(targetMotion.x * lead, 0.0D, targetMotion.z * lead);
        Vec3 toward = new Vec3(predicted.x - dragon.getX(), 0.0D, predicted.z - dragon.getZ());
        if (toward.lengthSqr() < 1.0E-4D) return;
        Vec3 impulse = toward.normalize().scale(enraged ? 0.34D : 0.27D);
        if (!level.noCollision(dragon, dragon.getBoundingBox().move(impulse.x * 2.0D, 0.0D, impulse.z * 2.0D))) {
            // Do not spend the cooldown when a wall or another collision blocks the burst.
            return;
        }

        dragon.setDeltaMovement(dragon.getDeltaMovement().add(impulse.x, enraged ? 0.12D : 0.08D, impulse.z));
        dragon.hasImpulse = true;
        dragon.getPersistentData().putLong(NEXT_CHARGE_TAG, now + cooldown);
        dragon.getPersistentData().putLong(NEXT_SPECIAL_TAG, now + 25L);
        level.sendParticles(enraged ? ParticleTypes.FLAME : ParticleTypes.CLOUD,
                dragon.getX(), dragon.getY() + 0.2D, dragon.getZ(),
                enraged ? 10 : 6, 0.35D, 0.08D, 0.35D, 0.015D);
    }

    /**
     * Short-range roar shockwave: adult wild dragons can disrupt nearby players,
     * creating space when a fight gets too close. It uses vanilla effects and has
     * a persistent world-time cooldown, so reloading the dragon cannot reset it.
     */
    private static void tryRoarShockwave(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.getDragonStage() < 3 || dragon.isBreathingFire() || dragon.isFlying()) return;
        if (!(dragon.getTarget() instanceof Player target)) return;
        if (target.isRemoved() || target.isDeadOrDying() || target.isCreative() || target.isSpectator()) return;

        // A badly wounded adult enters an enraged phase. This strengthens the existing
        // roar without adding another ticking task or replacing Ice and Fire's AI.
        boolean enraged = dragon.getMaxHealth() > 0.0F
                && dragon.getHealth() / dragon.getMaxHealth() <= 0.30F;
        double radius = enraged ? 7.0D : ROAR_RADIUS;
        if (dragon.distanceToSqr(target) > radius * radius) return;

        long now = level.getGameTime();
        long roarCooldown = enraged ? 180L : ROAR_COOLDOWN_TICKS;
        if (now < dragon.getPersistentData().getLong(NEXT_ROAR_TAG)) return;
        if (now < dragon.getPersistentData().getLong(NEXT_SPECIAL_TAG)) return;
        if (hasNearbyPackSpecialInProgress(dragon, level, now)) return;

        level.playSound(null, dragon.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL,
                SoundSource.HOSTILE, enraged ? 1.35F : 1.15F, enraged ? 0.58F : 0.72F);
        level.sendParticles(ParticleTypes.CLOUD, dragon.getX(), dragon.getY() + 0.2D, dragon.getZ(),
                enraged ? 32 : 18, enraged ? 1.25D : 0.8D, 0.12D,
                enraged ? 1.25D : 0.8D, 0.025D);

        for (Player player : level.getEntitiesOfClass(Player.class,
                dragon.getBoundingBox().inflate(radius))) {
            if (player.isRemoved() || player.isDeadOrDying() || player.isCreative() || player.isSpectator()) continue;
            if (player.distanceToSqr(dragon) > radius * radius) continue;

            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,
                    enraged ? 60 : 35, enraged ? 2 : 1));
            if (enraged) {
                player.hurt(DamageSource.mobAttack(dragon), 2.0F);
            }
            double dx = player.getX() - dragon.getX();
            double dz = player.getZ() - dragon.getZ();
            if (dx * dx + dz * dz < 1.0E-4D) {
                dx = (player.getId() & 1) == 0 ? 1.0D : -1.0D;
                dz = 0.0D;
            }
            player.knockback(enraged ? 1.0D : 0.72D, dx, dz);
        }
        dragon.getPersistentData().putLong(NEXT_ROAR_TAG, now + roarCooldown);
        dragon.getPersistentData().putLong(NEXT_SPECIAL_TAG, now + SPECIAL_LOCKOUT_TICKS);
    }

    /**
     * Close-range ground slam for adult wild dragons. It damages and pushes nearby players;
     * a shared short lockout prevents the slam and roar from firing together.
     */
    private static void tryGroundSlam(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.getDragonStage() < 3 || !dragon.isOnGround() || dragon.isBreathingFire() || dragon.isFlying()) return;

        long now = level.getGameTime();
        long windupUntil = dragon.getPersistentData().getLong(SLAM_WINDUP_TAG);
        Player target = dragon.getTarget() instanceof Player player ? player : null;

        // The enraged state is snapshotted when the warning starts so the attack's
        // radius and damage cannot change unexpectedly during its wind-up.
        if (windupUntil > 0L) {
            boolean enragedSlam = dragon.getPersistentData().getBoolean(SLAM_ENRAGED_TAG);
            double slamRadius = enragedSlam ? 4.2D : SLAM_RADIUS;
            if (target == null || target.isRemoved() || target.isDeadOrDying()
                    || target.isCreative() || target.isSpectator()
                    || dragon.distanceToSqr(target) > slamRadius * slamRadius
                    || !dragon.isOnGround() || dragon.isFlying() || dragon.isBreathingFire()) {
                dragon.getPersistentData().putLong(SLAM_WINDUP_TAG, 0L);
                dragon.getPersistentData().putBoolean(SLAM_ENRAGED_TAG, false);
                return;
            }
            if (now < windupUntil) {
                // Keep a visible ground-level ring during the wind-up so players can
                // read the danger zone instead of relying on sound alone.
                double ringY = dragon.getY() + 0.12D;
                int points = enragedSlam ? 16 : 12;
                for (int i = 0; i < points; i++) {
                    double angle = (Math.PI * 2.0D * i) / points;
                    double px = dragon.getX() + Math.cos(angle) * slamRadius;
                    double pz = dragon.getZ() + Math.sin(angle) * slamRadius;
                    level.sendParticles(enragedSlam ? ParticleTypes.FLAME : ParticleTypes.CLOUD,
                            px, ringY, pz, 1, 0.02D, 0.01D, 0.02D, 0.0D);
                }
                return;
            }

            level.playSound(null, dragon.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL,
                    SoundSource.HOSTILE, enragedSlam ? 1.2F : 0.9F, enragedSlam ? 0.78F : 1.15F);
            for (Player player : level.getEntitiesOfClass(Player.class,
                    dragon.getBoundingBox().inflate(slamRadius))) {
                if (player.isRemoved() || player.isDeadOrDying() || player.isCreative() || player.isSpectator()) continue;
                if (player.distanceToSqr(dragon) > slamRadius * slamRadius) continue;
                player.hurt(DamageSource.mobAttack(dragon), enragedSlam ? 6.0F : 4.0F);
                double dx = player.getX() - dragon.getX();
                double dz = player.getZ() - dragon.getZ();
                if (dx * dx + dz * dz < 1.0E-4D) {
                    dx = (player.getId() & 1) == 0 ? 1.0D : -1.0D;
                    dz = 0.0D;
                }
                player.knockback(enragedSlam ? 1.25D : 0.95D, dx, dz);
            }
            dragon.getPersistentData().putLong(SLAM_WINDUP_TAG, 0L);
            dragon.getPersistentData().putBoolean(SLAM_ENRAGED_TAG, false);
            dragon.getPersistentData().putLong(NEXT_SLAM_TAG, now + (enragedSlam ? 120L : SLAM_COOLDOWN_TICKS));
            return;
        }

        if (target == null || target.isRemoved() || target.isDeadOrDying()
                || target.isCreative() || target.isSpectator()) return;
        boolean enragedSlam = dragon.getMaxHealth() > 0.0F
                && dragon.getHealth() / dragon.getMaxHealth() <= 0.30F;
        double slamRadius = enragedSlam ? 4.2D : SLAM_RADIUS;
        if (dragon.distanceToSqr(target) > slamRadius * slamRadius) return;
        if (now < dragon.getPersistentData().getLong(NEXT_SLAM_TAG)) return;
        if (now < dragon.getPersistentData().getLong(NEXT_SPECIAL_TAG)) return;
        if (hasNearbyPackSpecialInProgress(dragon, level, now)) return;

        // Telegraph the attack: enraged dragons give a slightly longer warning,
        // but their larger damage zone remains clearly marked with flame particles.
        dragon.getPersistentData().putLong(SLAM_WINDUP_TAG, now + (enragedSlam ? 14L : 10L));
        dragon.getPersistentData().putBoolean(SLAM_ENRAGED_TAG, enragedSlam);
        dragon.getPersistentData().putLong(NEXT_SPECIAL_TAG, now + SPECIAL_LOCKOUT_TICKS);
        level.playSound(null, dragon.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL,
                SoundSource.HOSTILE, enragedSlam ? 1.0F : 0.75F, enragedSlam ? 0.82F : 1.35F);
        level.sendParticles(enragedSlam ? ParticleTypes.FLAME : ParticleTypes.CLOUD,
                dragon.getX(), dragon.getY() + 0.15D, dragon.getZ(),
                enragedSlam ? 28 : 18, enragedSlam ? 1.2D : 0.9D,
                0.08D, enragedSlam ? 1.2D : 0.9D, 0.02D);
    }



    /**
     * Adds a modest sandstone ruin and an emerald loot chest near an existing
     * wild adult dragon's home in a desert. It only places blocks in air above
     * solid ground and records completion after the chest has been created.
     */
    private static void tryDecorateDesertLair(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.isTame() || dragon.homePos == null || !isInHomeDimension(dragon, level)) return;
        BlockPos home = dragon.homePos.getPosition();
        if (home == null || !level.hasChunkAt(home) || !level.getBiome(home).is(Biomes.DESERT)) return;

        // Keep the decoration away from the exact nest position so it does not
        // overwrite an egg, hatchling, or the block the dragon is standing on.
        BlockPos center = home.offset(4, 0, 3);
        if (!level.hasChunkAt(center)) return;
        int surfaceY = center.getY();
        boolean foundGround = false;
        for (int dy = 4; dy >= -4; dy--) {
            BlockPos ground = center.offset(0, dy, 0);
            if (!level.hasChunkAt(ground)) return;
            if (level.getBlockState(ground).isSolidRender(level, ground)
                    && level.getBlockState(ground.above()).isAir()) {
                surfaceY = ground.getY();
                foundGround = true;
                break;
            }
        }
        if (!foundGround) return;

        BlockPos floor = new BlockPos(center.getX(), surfaceY + 1, center.getZ());
        BlockPos chestPos = floor.offset(1, 0, 1);
        if (!level.getBlockState(chestPos).isAir() || !level.getBlockState(chestPos.above()).isAir()) return;

        // A broken, low sandstone outline reads as a small ruin without replacing
        // large portions of the naturally generated desert terrain.
        BlockPos[] ruinBlocks = new BlockPos[] {
                floor, floor.east(2), floor.west(2), floor.north(2), floor.south(2),
                floor.east(2).north(2), floor.west(2).south(2),
                floor.east(2).south(2), floor.west(2).north(2)
        };
        for (BlockPos pos : ruinBlocks) {
            if (level.getBlockState(pos).isAir()) {
                level.setBlock(pos, Blocks.CUT_SANDSTONE.defaultBlockState(), 3);
            }
        }

        // Broken corner pillars make the site read more like an old desert ruin.
        // Only place into air so terrain, entities, and existing structures are not overwritten.
        BlockPos[] pillarBases = new BlockPos[] {
                floor.east(2).north(2), floor.west(2).north(2),
                floor.east(2).south(2), floor.west(2).south(2)
        };
        for (int i = 0; i < pillarBases.length; i++) {
            BlockPos base = pillarBases[i];
            int height = (i == 0 || i == 3) ? 2 : 1;
            for (int dy = 1; dy <= height; dy++) {
                BlockPos pillar = base.above(dy);
                if (level.getBlockState(pillar).isAir()) {
                    level.setBlock(pillar, Blocks.SANDSTONE.defaultBlockState(), 3);
                }
            }
            BlockPos cap = base.above(height + 1);
            if (level.getBlockState(cap).isAir()) {
                level.setBlock(cap, Blocks.CHISELED_SANDSTONE.defaultBlockState(), 3);
            }
        }

        level.setBlock(chestPos, Blocks.CHEST.defaultBlockState(), 3);
        if (level.getBlockEntity(chestPos) instanceof ChestBlockEntity chest) {
            chest.setLootTable(new ResourceLocation(PrimalAwakening.MOD_ID,
                    "chests/desert_dragon_lair"), level.random.nextLong());
            dragon.getPersistentData().putBoolean(DESERT_LAIR_DECORATED_TAG, true);
            level.playSound(null, chestPos, SoundEvents.CHEST_OPEN, SoundSource.BLOCKS, 0.35F, 1.2F);
        } else {
            // If the block entity could not initialize, remove the temporary chest
            // and retry on a later tick instead of permanently consuming the attempt.
            level.removeBlock(chestPos, false);
        }
    }

    /**
     * Prototype desert-lair ability: adult wild dragons whose home is in a desert
     * kick up a short sandstorm around nearby hostile players. This deliberately
     * reuses vanilla effects and particles; it is not a separate dragon entity or model.
     */
    private static void tryDesertSandstorm(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.getDragonStage() < 3 || dragon.isTame() || dragon.isFlying()
                || dragon.isBreathingFire() || dragon.homePos == null) return;
        if (!(dragon.getTarget() instanceof Player target)) return;
        if (target.isRemoved() || target.isDeadOrDying() || target.isCreative() || target.isSpectator()) return;

        BlockPos home = dragon.homePos.getPosition();
        if (home == null || !isInHomeDimension(dragon, level)) return;
        if (!level.getBiome(home).is(Biomes.DESERT)) return;
        if (dragon.distanceToSqr(target) > SANDSTORM_RADIUS * SANDSTORM_RADIUS) return;

        long now = level.getGameTime();
        if (now < dragon.getPersistentData().getLong(NEXT_SANDSTORM_TAG)) return;

        // Short telegraph: a ring of sand particles gives players a visual cue.
        BlockParticleOption sand = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.SAND.defaultBlockState());
        for (int i = 0; i < 36; i++) {
            double angle = Math.PI * 2.0D * i / 36.0D;
            double x = dragon.getX() + Math.cos(angle) * 4.0D;
            double z = dragon.getZ() + Math.sin(angle) * 4.0D;
            level.sendParticles(sand, x, dragon.getY() + 0.25D, z, 3,
                    0.25D, 0.45D, 0.25D, 0.04D);
        }
        level.playSound(null, dragon.blockPosition(), SoundEvents.SAND_PLACE,
                SoundSource.HOSTILE, 1.2F, 0.65F + level.random.nextFloat() * 0.2F);

        AABB area = dragon.getBoundingBox().inflate(SANDSTORM_RADIUS, 2.0D, SANDSTORM_RADIUS);
        for (Player player : level.getEntitiesOfClass(Player.class, area)) {
            if (player.isCreative() || player.isSpectator() || player.isRemoved() || player.isDeadOrDying()) continue;
            if (player.distanceToSqr(dragon) > SANDSTORM_RADIUS * SANDSTORM_RADIUS) continue;
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, false, true));
            player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0, false, true));
            player.hurt(DamageSource.GENERIC, 2.0F);
            Vec3 push = player.position().subtract(dragon.position()).normalize().scale(0.45D);
            player.push(push.x, 0.12D, push.z);
        }
        dragon.getPersistentData().putLong(NEXT_SANDSTORM_TAG, now + SANDSTORM_COOLDOWN_TICKS);
    }

    /**
     * Prototype hot-sand burst for adult wild dragons based in a desert. The warning
     * ring uses vanilla sandstone particles; this is an area attack, not a new breath
     * animation or a separate Desert Dragon entity.
     */
    private static void tryHotSandBurst(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.getDragonStage() < 3 || dragon.isTame() || dragon.isFlying()
                || dragon.isBreathingFire() || dragon.homePos == null) return;
        if (!(dragon.getTarget() instanceof Player target)) return;
        if (target.isRemoved() || target.isDeadOrDying() || target.isCreative() || target.isSpectator()) return;

        BlockPos home = dragon.homePos.getPosition();
        if (home == null || !isInHomeDimension(dragon, level) || !level.getBiome(home).is(Biomes.DESERT)) return;
        if (dragon.distanceToSqr(target) > HOT_SAND_RADIUS * HOT_SAND_RADIUS) return;

        long now = level.getGameTime();
        if (now < dragon.getPersistentData().getLong(NEXT_HOT_SAND_TAG)) return;
        // Avoid chaining both desert prototypes on the same tick.
        if (now < dragon.getPersistentData().getLong(NEXT_SANDSTORM_TAG)) return;

        BlockParticleOption hotSand = new BlockParticleOption(ParticleTypes.BLOCK,
                Blocks.SANDSTONE.defaultBlockState());
        for (int i = 0; i < 24; i++) {
            double angle = Math.PI * 2.0D * i / 24.0D;
            double x = dragon.getX() + Math.cos(angle) * 2.7D;
            double z = dragon.getZ() + Math.sin(angle) * 2.7D;
            level.sendParticles(hotSand, x, dragon.getY() + 0.1D, z, 3,
                    0.18D, 0.15D, 0.18D, 0.02D);
        }
        level.sendParticles(ParticleTypes.FLAME, dragon.getX(), dragon.getY() + 0.25D,
                dragon.getZ(), 20, 1.4D, 0.15D, 1.4D, 0.025D);
        level.playSound(null, dragon.blockPosition(), SoundEvents.FIRECHARGE_USE,
                SoundSource.HOSTILE, 0.9F, 0.7F + level.random.nextFloat() * 0.15F);

        AABB area = dragon.getBoundingBox().inflate(HOT_SAND_RADIUS, 1.5D, HOT_SAND_RADIUS);
        for (Player player : level.getEntitiesOfClass(Player.class, area)) {
            if (player.isCreative() || player.isSpectator() || player.isRemoved() || player.isDeadOrDying()) continue;
            if (player.distanceToSqr(dragon) > HOT_SAND_RADIUS * HOT_SAND_RADIUS) continue;
            player.hurt(DamageSource.GENERIC, 3.0F);
            player.setSecondsOnFire(2);
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 0, false, true));
        }
        dragon.getPersistentData().putLong(NEXT_HOT_SAND_TAG, now + HOT_SAND_COOLDOWN_TICKS);
    }

    /**
     * Performs a cooldown-limited lateral dodge when a player projectile is visibly
     * travelling toward an adult wild dragon. Vanilla/Ice and Fire attack AI is untouched.
     */
    private static void tryDodgeProjectile(EntityDragonBase dragon, ServerLevel level) {
        long now = level.getGameTime();
        if (now < dragon.getPersistentData().getLong(NEXT_DODGE_TAG)) return;

        for (Projectile projectile : level.getEntitiesOfClass(Projectile.class,
                dragon.getBoundingBox().inflate(DODGE_SCAN_RADIUS),
                candidate -> !candidate.isRemoved() && candidate.getOwner() instanceof Player)) {
            Vec3 projectileVelocity = projectile.getDeltaMovement();
            if (projectileVelocity.lengthSqr() < 1.0E-4D) continue;

            // Predict the projectile's closest point on its current trajectory. This
            // avoids wasting a dodge on arrows that are moving toward the dragon's
            // general direction but will actually pass well to the side.
            Vec3 dragonCenter = dragon.position().add(0.0D, dragon.getBbHeight() * 0.5D, 0.0D);
            Vec3 towardDragon = dragonCenter.subtract(projectile.position());
            double timeToClosest = towardDragon.dot(projectileVelocity) / projectileVelocity.lengthSqr();
            if (timeToClosest <= 0.0D || timeToClosest > DODGE_MAX_PREDICTION_TICKS) continue;
            Vec3 closestPoint = projectile.position().add(projectileVelocity.scale(timeToClosest));
            if (closestPoint.distanceToSqr(dragonCenter) > DODGE_PATH_RADIUS * DODGE_PATH_RADIUS) continue;

            // Check both sidesteps before committing. A fixed left/right choice can
            // push a dragon into a cliff or wall, so prefer the clear side when only
            // one candidate bounding box is collision-free.
            Vec3 lateral = new Vec3(-projectileVelocity.z, 0.0D, projectileVelocity.x);
            if (lateral.lengthSqr() < 1.0E-4D) lateral = new Vec3(1.0D, 0.0D, 0.0D);
            lateral = lateral.normalize().scale(0.48D);
            Vec3 opposite = lateral.scale(-1.0D);
            boolean canMoveLateral = level.noCollision(dragon,
                    dragon.getBoundingBox().move(lateral.x, 0.0D, lateral.z));
            boolean canMoveOpposite = level.noCollision(dragon,
                    dragon.getBoundingBox().move(opposite.x, 0.0D, opposite.z));
            if (!canMoveLateral && !canMoveOpposite) continue;

            Vec3 dodge;
            if (canMoveLateral && canMoveOpposite) {
                dodge = (dragon.getId() & 1) == 0 ? lateral : opposite;
            } else {
                dodge = canMoveLateral ? lateral : opposite;
            }
            dragon.setDeltaMovement(dragon.getDeltaMovement().add(dodge.x, 0.16D, dodge.z));
            dragon.hasImpulse = true;
            dragon.getPersistentData().putLong(NEXT_DODGE_TAG, now + DODGE_COOLDOWN_TICKS);
            return;
        }
    }

    private static boolean isInHomeDimension(EntityDragonBase dragon, ServerLevel level) {
        if (dragon.homePos == null) return false;
        String homeDimension = dragon.homePos.getDimension();
        // Empty dimensions can occur in legacy HomePosition data; treat those as local.
        return homeDimension == null || homeDimension.isEmpty()
                || homeDimension.equals(level.dimension().location().toString());
    }

    private static String nestKey(ServerLevel level, BlockPos home) {
        return level.dimension().location() + "|" + home.getX() + "," + home.getY() + "," + home.getZ();
    }

    /** Minimal persistent per-dimension registry; survives save/reload and avoids per-dragon duplication. */
    public static final class NestData extends SavedData {
        private final Set<String> processedNests = new HashSet<>();

        public NestData() {}

        public static NestData get(ServerLevel level) {
            return level.getDataStorage().computeIfAbsent(NestData::load, NestData::new, DATA_NAME);
        }

        public static NestData load(CompoundTag tag) {
            NestData data = new NestData();
            ListTag list = tag.getList("processed", 8);
            for (int i = 0; i < list.size(); i++) data.processedNests.add(list.getString(i));
            return data;
        }

        @Override
        public CompoundTag save(CompoundTag tag) {
            ListTag list = new ListTag();
            for (String key : processedNests) list.add(StringTag.valueOf(key));
            tag.put("processed", list);
            return tag;
        }
    }
}
