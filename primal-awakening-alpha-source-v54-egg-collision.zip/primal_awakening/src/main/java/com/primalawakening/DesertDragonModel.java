package com.primalawakening;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Blocky placeholder model; intended to be replaced by a full Ice-and-Fire-style dragon model. */
public class DesertDragonModel extends EntityModel<DesertDragonEntity> {
    private final ModelPart body, head, tail, leg1, leg2, leg3, leg4, wingL, wingR;
    public DesertDragonModel(ModelPart root) {
        body=root.getChild("body"); head=root.getChild("head"); tail=root.getChild("tail");
        leg1=root.getChild("leg1"); leg2=root.getChild("leg2"); leg3=root.getChild("leg3"); leg4=root.getChild("leg4");
        wingL=root.getChild("wingL"); wingR=root.getChild("wingR");
    }
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh=new MeshDefinition(); PartDefinition r=mesh.getRoot();
        r.addOrReplaceChild("body",CubeListBuilder.create().texOffs(0,0).addBox(-7,-5,-10,14,10,20),PartPose.offset(0,15,0));
        r.addOrReplaceChild("head",CubeListBuilder.create().texOffs(0,30).addBox(-4,-4,-9,8,7,9).addBox(-2,-2,-12,4,3,4),PartPose.offset(0,12,-10));
        r.addOrReplaceChild("tail",CubeListBuilder.create().texOffs(34,30).addBox(-2,-2,0,4,4,14).addBox(-1,-1,13,2,2,5),PartPose.offset(0,15,9));
        r.addOrReplaceChild("leg1",CubeListBuilder.create().texOffs(50,0).addBox(-2,0,-2,4,8,4),PartPose.offset(-5,17,-6));
        r.addOrReplaceChild("leg2",CubeListBuilder.create().texOffs(50,0).addBox(-2,0,-2,4,8,4),PartPose.offset(5,17,-6));
        r.addOrReplaceChild("leg3",CubeListBuilder.create().texOffs(50,0).addBox(-2,0,-2,4,8,4),PartPose.offset(-5,17,6));
        r.addOrReplaceChild("leg4",CubeListBuilder.create().texOffs(50,0).addBox(-2,0,-2,4,8,4),PartPose.offset(5,17,6));
        r.addOrReplaceChild("wingL",CubeListBuilder.create().texOffs(0,48).addBox(0,-1,-1,13,1,9),PartPose.offset(6,11,0));
        r.addOrReplaceChild("wingR",CubeListBuilder.create().texOffs(0,48).mirror().addBox(-13,-1,-1,13,1,9),PartPose.offset(-6,11,0));
        return LayerDefinition.create(mesh,96,64);
    }
    @Override public void setupAnim(DesertDragonEntity e,float limbSwing,float limbSwingAmount,float ageInTicks,float netHeadYaw,float headPitch) {
        head.yRot=netHeadYaw*Mth.DEG_TO_RAD; head.xRot=headPitch*Mth.DEG_TO_RAD;
        float swing=Mth.cos(limbSwing*0.65F)*0.55F*limbSwingAmount;
        leg1.xRot=swing; leg4.xRot=swing; leg2.xRot=-swing; leg3.xRot=-swing;
        wingL.zRot=Mth.sin(ageInTicks*0.18F)*0.12F; wingR.zRot=-wingL.zRot;
        tail.yRot=Mth.sin(ageInTicks*0.08F)*0.15F;
    }
    @Override public void renderToBuffer(com.mojang.blaze3d.vertex.PoseStack pose,com.mojang.blaze3d.vertex.VertexConsumer buffer,int light,int overlay,float red,float green,float blue,float alpha) {
        body.render(pose,buffer,light,overlay,red,green,blue,alpha); head.render(pose,buffer,light,overlay,red,green,blue,alpha); tail.render(pose,buffer,light,overlay,red,green,blue,alpha);
        leg1.render(pose,buffer,light,overlay,red,green,blue,alpha); leg2.render(pose,buffer,light,overlay,red,green,blue,alpha); leg3.render(pose,buffer,light,overlay,red,green,blue,alpha); leg4.render(pose,buffer,light,overlay,red,green,blue,alpha); wingL.render(pose,buffer,light,overlay,red,green,blue,alpha); wingR.render(pose,buffer,light,overlay,red,green,blue,alpha);
    }
}
