package com.primalawakening;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PrimalAwakening.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class DesertDragonClient {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(PrimalAwakening.MOD_ID, "desert_dragon"), "main");
    private DesertDragonClient() {}
    @SubscribeEvent public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(LAYER, DesertDragonModel::createBodyLayer);
    }
    @SubscribeEvent public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(PrimalAwakening.DESERT_DRAGON.get(), DesertDragonRenderer::new);
    }
}
