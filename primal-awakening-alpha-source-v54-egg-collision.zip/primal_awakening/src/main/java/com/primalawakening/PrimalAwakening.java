package com.primalawakening;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraftforge.event.world.BiomeLoadingEvent;
import net.minecraftforge.event.entity.RegisterSpawnPlacementsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(PrimalAwakening.MOD_ID)
public final class PrimalAwakening {
    public static final String MOD_ID = "primalawakening";
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);
    public static final RegistryObject<EntityType<DesertDragonEntity>> DESERT_DRAGON = ENTITIES.register("desert_dragon", () -> EntityType.Builder.of(DesertDragonEntity::new, MobCategory.MONSTER).sized(2.8F, 2.2F).fireImmune().build("desert_dragon"));

    public PrimalAwakening() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        DesertDragonEggs.BLOCKS.register(modBus);
        DesertScaleItems.ITEMS.register(modBus);
        ENTITIES.register(modBus);
        modBus.addListener(PrimalAwakening::registerSpawnPlacements);
        MinecraftForge.EVENT_BUS.addListener(PrimalAwakening::onBiomeLoading);
    }

    /** Register a normal ground spawn rule; the biome list below limits this species to deserts. */
    private static void registerSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        event.register(DESERT_DRAGON.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                net.minecraft.world.entity.monster.Monster::checkMonsterSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }

    /** Rare natural spawns in vanilla desert biomes; no forced chunk loading or structure generation. */
    private static void onBiomeLoading(BiomeLoadingEvent event) {
        if (event.getName() == null) return;
        String biome = event.getName().getPath();
        if (!(biome.equals("desert") || biome.equals("desert_hills")
                || biome.equals("desert_lakes"))) return;
        event.getSpawns().addSpawn(MobCategory.MONSTER,
                new MobSpawnSettings.SpawnerData(DESERT_DRAGON.get(), 1, 1, 1));
    }
}
