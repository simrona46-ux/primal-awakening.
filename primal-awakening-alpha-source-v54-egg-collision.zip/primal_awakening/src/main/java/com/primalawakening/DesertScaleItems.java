package com.primalawakening;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Four simple material items for the planned desert dragon color variants. */
public final class DesertScaleItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, PrimalAwakening.MOD_ID);

    public static final RegistryObject<Item> SAND_SCALE = register("sand_scale");
    public static final RegistryObject<Item> BRONZE_SCALE = register("bronze_scale");
    public static final RegistryObject<Item> IVORY_SCALE = register("ivory_scale");
    public static final RegistryObject<Item> TERRACOTTA_SCALE = register("terracotta_scale");

    private DesertScaleItems() {}

    private static RegistryObject<Item> register(String name) {
        return ITEMS.register(name, () -> new Item(new Item.Properties().tab(net.minecraft.world.item.CreativeModeTab.TAB_MISC)));
    }
}
