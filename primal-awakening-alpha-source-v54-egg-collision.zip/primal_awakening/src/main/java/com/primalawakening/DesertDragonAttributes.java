package com.primalawakening;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PrimalAwakening.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class DesertDragonAttributes {
    private DesertDragonAttributes() {}
    @SubscribeEvent public static void register(EntityAttributeCreationEvent event) {
        event.put(PrimalAwakening.DESERT_DRAGON.get(), DesertDragonEntity.createAttributes().build());
    }
}
