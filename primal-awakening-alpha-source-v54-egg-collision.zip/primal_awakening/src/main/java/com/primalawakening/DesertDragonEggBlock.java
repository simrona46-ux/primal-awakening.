package com.primalawakening;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.util.RandomSource;

/** Placeable colored egg prototype. Incubates for three 4,000-tick stages (10 minutes total). */
public final class DesertDragonEggBlock extends Block {
    public static final IntegerProperty INCUBATION = IntegerProperty.create("incubation", 0, 2);
    private static final VoxelShape EGG_SHAPE = Shapes.box(0.1875D, 0.0D, 0.1875D, 0.8125D, 0.4375D, 0.8125D);
    private final int variant;

    public DesertDragonEggBlock(int variant) {
        super(BlockBehaviour.Properties.copy(Blocks.TURTLE_EGG).strength(0.5F).noOcclusion());
        this.variant = Math.floorMod(variant, 4);
        registerDefaultState(stateDefinition.any().setValue(INCUBATION, 0));
    }

    /** Keep collision and selection close to the small egg model instead of using a full cube. */
    @Override public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return EGG_SHAPE;
    }

    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(INCUBATION);
    }

    @Override public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (!level.isClientSide && !state.is(oldState.getBlock())) level.scheduleTick(pos, this, 4000);
    }

    @Override public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!isSuitableSite(level, pos)) {
            // Incubation pauses outside a desert on sand/red sand; retry without losing progress.
            level.scheduleTick(pos, this, 200);
            return;
        }
        int stage = state.getValue(INCUBATION);
        if (stage < 2) {
            level.setBlock(pos, state.setValue(INCUBATION, stage + 1), 3);
            level.scheduleTick(pos, this, 4000);
            level.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5D, pos.getY() + 0.25D, pos.getZ() + 0.5D, 4, 0.2D, 0.05D, 0.2D, 0.005D);
            return;
        }

        Entity hatchling = PrimalAwakening.DESERT_DRAGON.get().create(level);
        if (hatchling instanceof DesertDragonEntity dragon) {
            dragon.setVariant(variant);
            dragon.setAgeStage(1);
            dragon.moveTo(pos.getX() + 0.5D, pos.getY() + 0.05D, pos.getZ() + 0.5D, random.nextFloat() * 360.0F, 0.0F);
            if (level.noCollision(dragon) && level.addFreshEntity(dragon)) {
                level.removeBlock(pos, false);
                level.playSound(null, pos, SoundEvents.TURTLE_EGG_HATCH, SoundSource.BLOCKS, 1.0F, 0.8F + random.nextFloat() * 0.4F);
                level.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5D, pos.getY() + 0.4D, pos.getZ() + 0.5D, 18, 0.35D, 0.2D, 0.35D, 0.03D);
            } else {
                dragon.discard();
                level.scheduleTick(pos, this, 200);
            }
        } else {
            if (hatchling != null) hatchling.discard();
            level.scheduleTick(pos, this, 200);
        }
    }

    private static boolean isSuitableSite(Level level, BlockPos pos) {
        BlockPos below = pos.below();
        boolean sand = level.getBlockState(below).is(Blocks.SAND) || level.getBlockState(below).is(Blocks.RED_SAND);
        return sand && level.getBiome(pos).is(Biomes.DESERT);
    }
}
