package com.primalawakening;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Four placeable eggs; variant index matches DesertDragonEntity's variant values. */
public final class DesertDragonEggs {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, PrimalAwakening.MOD_ID);
    public static final RegistryObject<Block> SAND_EGG = egg("sand_egg", 0);
    public static final RegistryObject<Block> BRONZE_EGG = egg("bronze_egg", 1);
    public static final RegistryObject<Block> IVORY_EGG = egg("ivory_egg", 2);
    public static final RegistryObject<Block> TERRACOTTA_EGG = egg("terracotta_egg", 3);

    private DesertDragonEggs() {}

    private static RegistryObject<Block> egg(String name, int variant) {
        RegistryObject<Block> block = BLOCKS.register(name, () -> new DesertDragonEggBlock(variant));
        DesertScaleItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties().tab(net.minecraft.world.item.CreativeModeTab.TAB_DECORATIONS)));
        return block;
    }
}
