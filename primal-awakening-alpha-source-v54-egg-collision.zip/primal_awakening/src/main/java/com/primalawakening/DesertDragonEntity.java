package com.primalawakening;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.level.ServerLevelAccessor;
import javax.annotation.Nullable;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

/** First registered gameplay prototype; uses a simple custom renderer until the full IAF-style model is ready. */
public class DesertDragonEntity extends Monster {
    private int sandBurstCooldown = 0;
    private int ageTicks = 0;
    private int burrowTicks = 0;
    private double burrowOriginY = 0.0D;
    private int burrowCooldown = 0;
    private int lungeTicks = 0;
    private int lungeCooldown = 0;
    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(DesertDragonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> AGE_STAGE = SynchedEntityData.defineId(DesertDragonEntity.class, EntityDataSerializers.INT);

    public DesertDragonEntity(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 180.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.24D).add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D).add(Attributes.ARMOR, 10.0D).add(Attributes.KNOCKBACK_RESISTANCE, 0.8D);
    }

    @Override protected void registerGoals() {
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.15D, true));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        // Hatchlings and juveniles do not automatically hunt players; they can still defend themselves
        // through HurtByTargetGoal. Direct player hunting unlocks at the third growth stage.
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true, player -> getAgeStage() >= 3));
    }

    /** Assign a weighted coat only when the entity is first naturally spawned.
     *  Sand is common; terracotta is deliberately rare. Existing and hatched dragons
     *  keep their saved/inherited variant because this hook is not called on reload.
     */
    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData spawnData,
                                        @Nullable CompoundTag dataTag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
        // Choose appearance and age only for genuinely natural spawns. Spawned-from-egg
        // hatchlings and entities restored from saved data keep their inherited/saved values.
        if (reason == MobSpawnType.NATURAL && (dataTag == null || !dataTag.contains("DesertVariant"))) {
            float roll = this.random.nextFloat();
            if (roll < 0.50F) {
                setVariant(0); // sand: 50%
            } else if (roll < 0.75F) {
                setVariant(1); // bronze: 25%
            } else if (roll < 0.90F) {
                setVariant(2); // ivory: 15%
            } else {
                setVariant(3); // terracotta: 10%
            }

            // Most wild dragons are mature enough to defend a territory. The age is
            // assigned once at spawn; it does not reroll during chunk reloads.
            float ageRoll = this.random.nextFloat();
            if (ageRoll < 0.55F) {
                setAgeStage(3); // 55%: young adult
            } else if (ageRoll < 0.85F) {
                setAgeStage(4); // 30%: adult
            } else {
                setAgeStage(5); // 15%: fully grown
            }
        }
        return result;
    }

    @Override public void aiStep() {
        super.aiStep();
        if (!level.isClientSide) {
            // Stage durations: 7, 10, 15 and 20 Minecraft days (24,000 ticks/day).
            // Growth progress is stored in NBT and only advances while the entity is ticking.
            if (getAgeStage() < 5) {
                ageTicks++;
                int[] stageDurationTicks = {168000, 240000, 360000, 480000};
                int requiredTicks = stageDurationTicks[getAgeStage() - 1];
                if (ageTicks >= requiredTicks) {
                    ageTicks = 0;
                    setAgeStage(getAgeStage() + 1);
                    heal(Math.max(1.0F, getMaxHealth() * 0.05F));
                }
            }
            if (burrowCooldown > 0) burrowCooldown--;
            if (lungeCooldown > 0) lungeCooldown--;
            // Family defence: mature dragons of the same color protect nearby hatchlings.
            // A player must approach the young dragon before the adult retaliates.
            if (getAgeStage() >= 3 && getTarget() == null && tickCount % 20 == 0) {
                for (DesertDragonEntity young : level.getEntitiesOfClass(DesertDragonEntity.class,
                        getBoundingBox().inflate(24.0D), candidate -> candidate != this
                                && candidate.getAgeStage() <= 2 && candidate.getVariant() == getVariant())) {
                    Player intruder = level.getNearestPlayer(young, 8.0D);
                    if (intruder != null && !intruder.isSpectator() && !intruder.isCreative()
                            && !intruder.isDeadOrDying()) {
                        setTarget(intruder);
                        break;
                    }
                }
            }
            // A short wing-assisted leap gives adult dragons a way to close distance without
            // pretending this prototype already has Ice and Fire's full flight controller.
            if (lungeTicks > 0) {
                lungeTicks--;
                setNoGravity(true);
                LivingEntity lungeTarget = getTarget();
                if (lungeTarget != null && lungeTarget.isAlive()) {
                    double dx = lungeTarget.getX() - getX();
                    double dz = lungeTarget.getZ() - getZ();
                    double horizontal = Math.max(0.001D, Math.sqrt(dx * dx + dz * dz));
                    // Mild steering during the leap makes it track a moving target instead of
                    // continuing along the direction captured only at take-off.
                    double speed = 0.48D;
                    double vy = Math.max(-0.08D, Math.min(0.16D, (lungeTarget.getY() - getY()) * 0.025D));
                    setDeltaMovement(dx / horizontal * speed, vy, dz / horizontal * speed);
                    hasImpulse = true;
                }
                if (lungeTicks == 0) {
                    setNoGravity(false);
                    // Avoid carrying excessive horizontal momentum into normal ground combat.
                    net.minecraft.world.phys.Vec3 motion = getDeltaMovement();
                    setDeltaMovement(motion.x * 0.45D, Math.min(motion.y, 0.0D), motion.z * 0.45D);
                }
            }
            if (burrowTicks > 0) {
                burrowTicks--;
                setDeltaMovement(0.0D, 0.0D, 0.0D);
                setNoGravity(true);
                if (burrowTicks == 0) {
                    setPos(getX(), burrowOriginY, getZ());
                    setNoPhysics(false);
                    setNoGravity(false);
                    level.playSound(null, blockPosition(), SoundEvents.SAND_PLACE, SoundSource.HOSTILE, 1.2F, 0.7F);
                    for (int i = 0; i < 20; i++) {
                        level.addParticle(ParticleTypes.CLOUD, getX() + (random.nextDouble() - 0.5D) * 2.5D,
                                getY() + random.nextDouble(), getZ() + (random.nextDouble() - 0.5D) * 2.5D,
                                0.0D, 0.06D, 0.0D);
                    }
                }
                return;
            }
        }
        if (sandBurstCooldown > 0) sandBurstCooldown--;
        LivingEntity target = getTarget();
        if (!level.isClientSide && getAgeStage() >= 4 && lungeTicks <= 0 && lungeCooldown <= 0
                && target != null && target.isAlive() && distanceToSqr(target) >= 49.0D
                && distanceToSqr(target) <= 324.0D && random.nextInt(80) == 0) {
            double dx = target.getX() - getX();
            double dz = target.getZ() - getZ();
            double horizontal = Math.max(0.001D, Math.sqrt(dx * dx + dz * dz));
            setDeltaMovement(dx / horizontal * 0.72D, 0.38D + Math.min(0.22D, (target.getY() - getY()) * 0.04D), dz / horizontal * 0.72D);
            hasImpulse = true;
            lungeTicks = 24;
            lungeCooldown = 240; // 12 seconds
            setNoGravity(true);
            level.playSound(null, blockPosition(), SoundEvents.ENDER_DRAGON_FLAP, SoundSource.HOSTILE, 1.1F, 0.75F + random.nextFloat() * 0.2F);
            for (int i = 0; i < 12; i++) {
                level.addParticle(ParticleTypes.CLOUD, getX() + (random.nextDouble() - 0.5D) * 1.8D,
                        getY() + 0.2D, getZ() + (random.nextDouble() - 0.5D) * 1.8D,
                        (random.nextDouble() - 0.5D) * 0.12D, 0.08D, (random.nextDouble() - 0.5D) * 0.12D);
            }
        }
        // The adult prototype uses a close-range sand burst instead of pretending to be a full dragon flyer.
        if (!level.isClientSide && getAgeStage() >= 3 && target != null && target.isAlive()
                && burrowCooldown <= 0 && onSandSurface() && distanceToSqr(target) >= 16.0D
                && distanceToSqr(target) <= 144.0D && random.nextInt(100) == 0) {
            burrowCooldown = 900; // 45 seconds
            burrowTicks = 50; // 2.5 seconds underground
            burrowOriginY = getY();
            setNoPhysics(true);
            setNoGravity(true);
            setDeltaMovement(0.0D, 0.0D, 0.0D);
            setPos(getX(), getY() - 1.25D, getZ());
            level.playSound(null, blockPosition(), SoundEvents.SAND_BREAK, SoundSource.HOSTILE, 1.2F, 0.55F);
            for (int i = 0; i < 18; i++) {
                double angle = Math.PI * 2.0D * i / 18.0D;
                level.addParticle(ParticleTypes.CLOUD, getX() + Math.cos(angle), burrowOriginY,
                        getZ() + Math.sin(angle), Math.cos(angle) * 0.05D, 0.02D, Math.sin(angle) * 0.05D);
            }
        }
        if (!level.isClientSide && getAgeStage() >= 3 && target != null && target.isAlive()
                && distanceToSqr(target) <= 36.0D && sandBurstCooldown <= 0 && random.nextInt(35) == 0) {
            sandBurstCooldown = 420; // 21 seconds at 20 ticks per second
            level.playSound(null, blockPosition(), SoundEvents.SAND_BREAK, SoundSource.HOSTILE, 1.4F, 0.65F + random.nextFloat() * 0.2F);
            for (int i = 0; i < 32; i++) {
                double angle = (Math.PI * 2.0D * i) / 32.0D;
                double radius = 1.2D + random.nextDouble() * 2.2D;
                level.addParticle(ParticleTypes.CLOUD, getX() + Math.cos(angle) * radius, getY() + 0.2D,
                        getZ() + Math.sin(angle) * radius, Math.cos(angle) * 0.08D, 0.04D, Math.sin(angle) * 0.08D);
            }
            for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(3.5D), e -> e != this && e.isAlive() && e != getTarget() && e instanceof Player)) {
                victim.hurt(DamageSource.mobAttack(this), 3.0F);
                victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, 1));
                victim.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0));
            }
            if (target instanceof Player) {
                target.hurt(DamageSource.mobAttack(this), 3.0F);
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, 1));
                target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0));
            }
        }
    }

    private boolean onSandSurface() {
        net.minecraft.core.BlockPos below = blockPosition().below();
        return level.getBlockState(below).is(Blocks.SAND) || level.getBlockState(below).is(Blocks.RED_SAND);
    }

    /** Keep the physical hitbox proportional to the age-scaled rendered model. */
    @Override public EntityDimensions getDimensions(Pose pose) {
        float visualScale = 0.65F + getAgeStage() * 0.18F;
        float normalized = visualScale / 1.55F;
        return EntityDimensions.scalable(2.8F * normalized, 2.2F * normalized);
    }

    @Override protected void defineSynchedData() {
        super.defineSynchedData(); entityData.define(VARIANT, 0); entityData.define(AGE_STAGE, 1);
    }
    public int getVariant() { return entityData.get(VARIANT); }
    public void setVariant(int value) { entityData.set(VARIANT, Math.floorMod(value, 4)); }
    public int getAgeStage() { return entityData.get(AGE_STAGE); }
    public void setAgeStage(int value) {
        int nextStage = Math.max(1, Math.min(5, value));
        if (entityData.get(AGE_STAGE) != nextStage) {
            entityData.set(AGE_STAGE, nextStage);
            // Rebuild the physical bounding box immediately when the model grows.
            // Without this call the rendered dragon can become larger while its old
            // collision/hitbox dimensions remain until another pose refresh occurs.
            refreshDimensions();
        }
    }
    @Override public MobType getMobType() { return MobType.UNDEFINED; }
    @Override public boolean fireImmune() { return true; }
    @Override public void addAdditionalSaveData(CompoundTag tag) { super.addAdditionalSaveData(tag); tag.putInt("DesertVariant", getVariant()); tag.putInt("DesertAgeStage", getAgeStage()); tag.putInt("DesertAgeTicks", ageTicks); tag.putInt("SandBurstCooldown", sandBurstCooldown); tag.putInt("BurrowCooldown", burrowCooldown); tag.putInt("LungeTicks", lungeTicks); tag.putInt("LungeCooldown", lungeCooldown); }
    @Override public void readAdditionalSaveData(CompoundTag tag) { super.readAdditionalSaveData(tag); if(tag.contains("DesertVariant")) setVariant(tag.getInt("DesertVariant")); if(tag.contains("DesertAgeStage")) setAgeStage(tag.getInt("DesertAgeStage")); if(tag.contains("DesertAgeTicks")) ageTicks = Math.max(0, tag.getInt("DesertAgeTicks")); if(tag.contains("SandBurstCooldown")) sandBurstCooldown = Math.max(0, tag.getInt("SandBurstCooldown")); if(tag.contains("BurrowCooldown")) burrowCooldown = Math.max(0, tag.getInt("BurrowCooldown")); if(tag.contains("LungeTicks")) lungeTicks = Math.max(0, tag.getInt("LungeTicks")); if(tag.contains("LungeCooldown")) lungeCooldown = Math.max(0, tag.getInt("LungeCooldown")); }
    @Override protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        int min = new int[]{1,3,7,12,18}[getAgeStage()-1];
        int max = new int[]{3,7,12,18,24}[getAgeStage()-1];
        int count = min + random.nextInt(max-min+1) + random.nextInt(Math.max(1, looting+1));
        net.minecraft.world.item.Item item = switch(getVariant()) { case 1 -> DesertScaleItems.BRONZE_SCALE.get(); case 2 -> DesertScaleItems.IVORY_SCALE.get(); case 3 -> DesertScaleItems.TERRACOTTA_SCALE.get(); default -> DesertScaleItems.SAND_SCALE.get(); };
        while(count > 0) { int n = Math.min(count, item.getMaxStackSize()); spawnAtLocation(new net.minecraft.world.item.ItemStack(item, n)); count -= n; }
    }
}
