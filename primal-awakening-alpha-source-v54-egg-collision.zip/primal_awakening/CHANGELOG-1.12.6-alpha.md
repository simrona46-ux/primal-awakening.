# Primal Awakening 1.12.6-alpha

- Corrected dragon growth timing: each stage now takes eight full Minecraft days (192,000 ticks), matching the documented design.
- Aligned the Forge mod metadata and Gradle project version to 1.12.6-alpha.
- Retained the adult wing-assisted lunge, burrowing, sand burst, four variants, and age-scaled colored scale drops.

This is a source snapshot. It has not been compiled or tested in Minecraft in this environment.
