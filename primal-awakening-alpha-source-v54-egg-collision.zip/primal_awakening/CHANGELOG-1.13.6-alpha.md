# Primal Awakening 1.13.6-alpha

- Natural custom desert dragon spawns now receive one of four color variants.
- Sand is the common variant; bronze, ivory, and terracotta are progressively rarer.
- Variant is assigned once and retained across chunk reloads.
- This release is source-only; compile and in-game validation have not been performed.
