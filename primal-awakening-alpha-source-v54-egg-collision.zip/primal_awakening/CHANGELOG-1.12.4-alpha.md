# Primal Awakening 1.12.4-alpha

- Added automatic five-stage growth for the desert dragon. A stage advances every 48,000 entity ticks (two Minecraft days), up to stage 5.
- Added a prototype sand-burrow ambush for stage 3+ dragons when fighting on sand or red sand: brief underground phase, cooldown, warning particles, and emergence effects.
- Persisted age progress and burrow cooldown in entity NBT.

## Limitations
- This remains a prototype: no full dragon flight, egg lifecycle, natural spawn integration, or final Ice and Fire-style model yet.
- Source-level checks do not substitute for a Forge/Gradle compile or in-game test.
