# Primal Awakening 1.12.5-alpha

- Added a short wing-assisted lunge for stage 4–5 desert dragons to close medium-range gaps.
- Lunge uses a 12-second cooldown, particles and a wing sound; cooldown/timer are saved to entity NBT.
- This is not full sustained flight; full Ice and Fire-style flight controls, eggs, and natural spawning remain future work.
- Build/runtime compatibility is not confirmed until GitHub Actions and Minecraft testing succeed.
