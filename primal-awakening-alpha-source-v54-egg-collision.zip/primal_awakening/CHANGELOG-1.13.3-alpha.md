# Primal Awakening 1.13.3-alpha

- Added family defense to the custom desert dragon prototype: mature dragons can retaliate against non-creative, non-spectator players who approach a nearby same-color hatchling or juvenile.
- Defense checks run once per second and only when the adult has no existing target, preserving its current combat target and reducing per-tick entity scans.
- Existing Ice and Fire nest behavior, four egg colors, incubation, and age-based scale drops are retained.

Validation: archive integrity, JSON syntax, and Java brace balance checked. ForgeGradle compilation and in-game behavior have not been tested in this environment.
