# Primal Awakening 1.13.0-alpha

- Added four placeable desert dragon eggs: sand, bronze, ivory, and terracotta.
- Eggs incubate through three visible stages and hatch after 12,000 ticks (10 minutes) when placed on sand/red sand in the Desert biome.
- Hatchlings inherit the egg's variant and begin at growth stage 1.
- Incubation pauses outside the required biome/surface and resumes when conditions are suitable.
- Build and in-game verification still required.
