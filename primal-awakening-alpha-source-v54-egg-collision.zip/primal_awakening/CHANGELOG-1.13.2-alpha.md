# Primal Awakening 1.13.2-alpha

- Desert dragon hatchlings and juveniles no longer automatically target nearby players.
- Young dragons can still retaliate when attacked; active player hunting begins at growth stage 3.
- Preserved four egg variants, incubation stages, desert/sand conditions, and hatchling color inheritance.

Validation: source archive integrity and JSON syntax checked. Minecraft/Gradle compilation and in-game behavior have not been tested in this environment.
