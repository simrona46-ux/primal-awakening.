# Primal Awakening 1.13.4-alpha

- Added periodic return-to-lair pathing for adult wild Ice and Fire dragons after they have wandered more than 48 blocks from their home and have no active target.
- The return check runs every 100 ticks and does not force-load the home chunk or interrupt combat.
- Updated project and CI artifact version to 1.13.4-alpha.

Validation: source archive integrity and JSON syntax checked; Gradle compilation and in-game behavior have not been verified in this environment.
