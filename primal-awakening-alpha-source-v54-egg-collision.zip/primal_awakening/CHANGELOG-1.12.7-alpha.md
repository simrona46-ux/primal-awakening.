# Primal Awakening 1.12.7-alpha

- Improved the adult desert dragon's wing-assisted lunge: it now steers toward a living target during the leap rather than relying only on its take-off direction.
- Dampens horizontal momentum when the lunge ends to reduce overshooting and improve return to ground combat.
- Preserved growth timing, burrowing, sand burst, four variants, and age-scaled colored scale drops.

Source snapshot only; compilation and in-game behavior have not been verified in this environment.
