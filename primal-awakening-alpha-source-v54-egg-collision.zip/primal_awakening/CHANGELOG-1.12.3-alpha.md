# Primal Awakening 1.12.3-alpha
- Added an adult-stage close-range sand burst to the Desert Dragon prototype.
- The attack creates a cloud-particle warning/burst, plays a sand sound, and applies light damage, slowness, and brief blindness to nearby players.
- Attack cooldown is 21 seconds and is persisted in entity NBT.
- This remains a ground-based prototype: flight, proper burrowing, automatic growth, eggs, and natural desert spawning are not implemented yet.
- Static source review only; ForgeGradle compilation and in-game testing are still required.
