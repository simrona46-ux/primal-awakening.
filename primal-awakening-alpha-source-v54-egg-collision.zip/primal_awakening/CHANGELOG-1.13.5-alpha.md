# Primal Awakening 1.13.6-alpha

- Added rare natural spawning for the custom desert dragon in vanilla desert, desert hills, and desert lakes biomes.
- Registered ground spawn placement using the standard monster spawn predicate.
- Spawn weight is intentionally low (1) with one dragon per spawn group to avoid overcrowding.
- No custom structures or forced chunk loading are introduced by this change.

## Validation
- Source archive and JSON syntax checked.
- ForgeGradle compilation and in-game spawn verification have not been run in this environment.
