# Primal Awakening 1.12.9-alpha

- Adjusted the Desert Dragon's physical dimensions by growth stage so the collision box follows the renderer's age scale more closely.
- Preserved the agreed growth durations: 7, 10, 15, and 20 Minecraft days.
- Preserved existing variant, combat, burrowing, and loot behavior.
- Build and in-game behavior still require verification with the project's Forge/Gradle environment.
